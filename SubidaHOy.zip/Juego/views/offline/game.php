<?php
if(!isset($_REQUEST['oponente'])){
    header("location:index.php");
    exit();
}

require_once("controllers/teamUsersController");
$teamController=new TeamUsersController;
// echo "Oponente: ".$_REQUEST['oponente'];

?>