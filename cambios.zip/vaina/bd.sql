DROP DATABASE IF EXISTS Digi;

CREATE DATABASE Digi  CHARACTER SET utf8 COLLATE utf8_spanish_ci;
USE Digi;

-- Tabla de usuarios
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT, -- ID del usuario
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    wins INT DEFAULT 0,
    loses INT DEFAULT 0,
    digievolutions INT DEFAULT 0, -- Cantidad de Digievoluciones disponibles
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de Digimons
CREATE TABLE digimons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) UNIQUE NOT NULL,
    -- health INT NOT NULL,
    attack INT NOT NULL,
    defense INT NOT NULL,
    -- speed INT NOT NULL,
    type ENUM('Vacuna', 'Virus', 'Animal', 'Planta', 'Elemental') NOT NULL,
    level TINYINT NOT NULL,
    next_evolution_id INT NULL, -- ID del siguiente Digimon
    image VARCHAR(255),
    CONSTRAINT fk_next_evolution FOREIGN KEY (next_evolution_id) REFERENCES digimons(id) ON UPDATE CASCADE
);

-- Relación entre usuarios y Digimons
CREATE TABLE digimons_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    digimon_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_digimons_users_users FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE,
    CONSTRAINT fk_digimons_users_digimons FOREIGN KEY (digimon_id) REFERENCES digimons(id) ON UPDATE CASCADE
);

-- Equipos de usuarios
CREATE TABLE team_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    digimon_id INT NOT NULL,
    CONSTRAINT fk_team_users_users FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE,
    CONSTRAINT fk_team_users_digimons FOREIGN KEY (digimon_id) REFERENCES digimons(id) ON UPDATE CASCADE
);

INSERT INTO users(username, password) VALUES("dani", "$2y$10$0cAboDTqx/BycOAYBupeOeGdXQdQHzjax6Hb5HM9rbYX6QX4mzif6");

INSERT INTO digimons (name, attack, defense, type, level, next_evolution_id, image) VALUES
-- Tipo Vacuna
('Koromon', 50, 30, 'Vacuna', 1, NULL, 'koromon.png'),
('Agumon', 80, 50, 'Vacuna', 2, NULL, 'agumon.png'),
('Greymon', 120, 80, 'Vacuna', 3, NULL, 'greymon.png'),
('MetalGreymon', 160, 110, 'Vacuna', 4, NULL, 'metalgreymon.png'),

-- Tipo Virus
('Tsukaimon', 45, 35, 'Virus', 1, NULL, 'tsukaimon.png'),
('Devimon', 85, 55, 'Virus', 2, NULL, 'devimon.png'),
('Myotismon', 130, 90, 'Virus', 3, NULL, 'myotismon.png'),
('VenomMyotismon', 170, 120, 'Virus', 4, NULL, 'venommyotismon.png'),

-- Tipo Planta
('Tanemon', 40, 35, 'Planta', 1, NULL, 'tanemon.png'),
('Palmon', 75, 55, 'Planta', 2, NULL, 'palmon.png'),
('Togemon', 115, 85, 'Planta', 3, NULL, 'togemon.png'),
('Lillymon', 155, 115, 'Planta', 4, NULL, 'lillymon.png'),

-- Tipo Animal
('Elecmon', 50, 40, 'Animal', 1, NULL, 'elecmon.png'),
('Leomon', 90, 70, 'Animal', 2, NULL, 'leomon.png'),
('GrapLeomon', 130, 100, 'Animal', 3, NULL, 'grapleomon.png'),
('SaberLeomon', 180, 130, 'Animal', 4, NULL, 'saberleomon.png');
