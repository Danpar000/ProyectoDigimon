document.addEventListener("DOMContentLoaded", () => {
    let nivel = document.getElementById("level");

    document.getElementById("level").addEventListener( "change", () => {
        let a = 0;
        switch(nivel.value){
            case "1":
                a = 1;
                console.log("Evoluciona al 2");
                break;
            case "2":
                console.log("Evoluciona al 3");
                break;
            case "3":
                console.log("Evoluciona al 4");
                break;
            case "4":
                console.log("NO evoluciona");
                break;
        }

        if (a != 10) {
            // Contenedor
            let div = document.createElement("div");
            div.className = "form-group";

            // Otros
            let label = document.createElement("label");
            label.setAttribute("for", "next_evolution_id");
            label.innerText = "Siguiente evolución";

            let select = document.createElement("select");
            select.setAttribute("id", "next_evolution_id");
            select.className = "next_evolution_id";
            

            fetch("controllers/digimonsController.php?accion=listarJson")
            .then(response => response.json())
            .then((data) => {
                    data.forEach(element => {
                        let option = document.createElement("option");
                        option.setAttribute("value", element.id);
                        option.innerText = element.id + ". " + element.name;
                        select.appendChild(option);
                    });
                })
            .catch(console.log("No se han podido cargar las evoluciones"));
            

            div.appendChild(label)
            div.appendChild(select)
            nivel.parentNode.appendChild(div);
        }
    })
});

