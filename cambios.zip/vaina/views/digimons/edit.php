<?php
require_once "controllers/digimonsController.php";
//recoger datos
if (!isset($_REQUEST["id"])) {
    header('location:index.php?accion=listar');
    unset($_SESSION["datos"]);
    unset($_SESSION["errores"]);
    exit();
}
$id = $_REQUEST["id"];
$controlador = new DigimonsController();
if ($id != null) {
    $digi = $controlador->ver($id);
}

$datos = [];
$visibilidad = "hidden";
$mensaje = "";
$clase = "alert alert-success";
$mostrarForm = true;
if ($client == null) {
    $visibilidad = "visible";
    $mensaje = "El cliente con id: {$id} no existe. Por favor vuelva a la pagina anterior";
    $clase = "alert alert-danger";
    $mostrarForm = false;
    unset($_SESSION["datos"]);
    unset($_SESSION["errores"]);
} else if (isset($_REQUEST["evento"]) && $_REQUEST["evento"] == "modificar") {
    $visibilidad = "visible";
    $mensaje = "Cliente con id {$id}, ha cambiado su idFiscal a {$client->idFiscal} y el nombre a {$client->contact_name} con éxito";
    if (isset($_REQUEST["error"])) {
        $mensaje = "No se ha podido modificar el cliente con id {$id}";
        $clase = "alert alert-danger";
        $errores = ($_SESSION["errores"]) ?? [];
        $datos = ($_SESSION["datos"]) ?? [];
    }
}
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h3">Editar Digimon con Id: <?= $id ?></h1>
    </div>
    <div id="contenido">
        <div id="msg" name="msg" class="<?= $clase ?>" <?= $visibilidad ?> > <?= $mensaje ?> </div>
        <?php
        if ($mostrarForm) {
        $errores=$_SESSION["errores"]??[];
        ?>
            <form action="index.php?tabla=client&accion=guardar&evento=modificar" method="POST">
                <input type="hidden" id="id" name="id" value="<?= $client->id ?>">
                <div class="form-group">
                    <label for="idFiscal">ID Fiscal</label>
                    <input type="text" required class="form-control" id="idFiscal" name="idFiscal" value="<?= $_SESSION["datos"]["idFiscal"] ?? $client->idFiscal ?>" placeholder="ID Fiscal">
                    <input type="hidden" id="idFiscalOriginal" name="idFiscalOriginal" value="<?= $client->idFiscal ?>">
                    <?= isset($errores["idFiscal"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "idFiscal") . '</div>' : ""; ?>
                </div>
                <div class="form-group">
                    <label for="contact_name">Nombre </label>
                    <input type="text" required class="form-control" id="contact_name" name="contact_name" value="<?= $_SESSION["datos"]["contact_name"] ?? $client->contact_name ?>" placeholder="Nombre del contacto">
                    <?= isset($errores["contact_name"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "contact_name") . '</div>' : ""; ?>
                </div>
                <div class="form-group">
                    <label for="contact_email">Email </label>
                    <input type="email" required class="form-control" id="contact_email" name="contact_email" value="<?= $_SESSION["datos"]["contact_email"] ?? $client->contact_email ?>" placeholder="Email del contacto">
                    <input type="hidden" id="contact_emailOriginal" name="contact_emailOriginal" value="<?= $client->contact_email ?>">
                    <?= isset($errores["contact_email"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "contact_email") . '</div>' : ""; ?>
                </div>
                <div class="form-group">
                    <label for="contact_phone_number">Teléfono </label>
                    <input type="number" class="form-control" id="contact_phone_number" name="contact_phone_number" value="<?= $_SESSION["datos"]["contact_phone_number"] ?? $client->contact_phone_number ?>" placeholder="Teléfono del contacto">
                    <?= isset($errores["contact_phone_number"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "contact_phone_number") . '</div>' : ""; ?>
                </div>
                <div class="form-group">
                    <label for="company_name">Nombre de la compañía </label>
                    <input type="text" required class="form-control" id="company_name" name="company_name" value="<?= $_SESSION["datos"]["company_name"] ?? $client->company_name ?>" placeholder="Nombre de la compañia">
                    <?= isset($errores["company_name"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "company_name") . '</div>' : ""; ?>
                </div>
                <div class="form-group">
                    <label for="company_address">Dirección de la compañía </label>
                    <input type="text" class="form-control" id="company_address" name="company_address" value="<?= $_SESSION["datos"]["company_address"] ?? $client->company_address ?>" placeholder="Dirección de la compañia">
                    <?= isset($errores["company_address"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "company_address") . '</div>' : ""; ?>
                </div>
                <div class="form-group">
                    <label for="company_phone_number">Teléfono de la compañía </label>
                    <input type="number" class="form-control" id="company_phone_number" name="company_phone_number" value="<?= $_SESSION["datos"]["company_phone_number"] ?? $client->company_phone_number ?>" placeholder="Teléfono de la compañia">
                    <?= isset($errores["company_phone_number"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "company_phone_number") . '</div>' : ""; ?>
                </div>

                <button type="submit" class="btn btn-primary">Guardar</button>
                <a class="btn btn-danger" href="index.php?tabla=client&accion=listar">Cancelar</a>
            </form>
        <?php
        } else {
        ?>
            <a href="index.php" class="btn btn-primary">Volver a Inicio</a>
        <?php
        }
        //Una vez mostrados los errores, los eliminamos
        unset($_SESSION["datos"]);
        unset($_SESSION["errores"]);
        ?>
    </div>
</main>