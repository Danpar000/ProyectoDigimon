<?php
require_once "assets/php/funciones.php";
$cadenaErrores = "";
$cadena = "";
$errores = [];
$datos = [];
$visibilidad = "invisible";
if (isset($_REQUEST["error"])) {
  $errores = ($_SESSION["errores"]) ?? [];
  $datos = ($_SESSION["datos"]) ?? [];
  $cadena = "Atención Se han producido Errores";
  $visibilidad = "visible";
}
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h3">Añadir cliente</h1>
  </div>
  <div id="contenido">
    <div id="alerta" class="alert alert-danger <?= $visibilidad ?>"><?= $cadena ?></div>
    <form action="index.php?tabla=client&accion=guardar&evento=crear" method="POST" id="miform" name="miform">
    <div class="form-group">
        <label for="idFiscal">Id Fiscal </label>
        <input type="text" required class="form-control" id="idFiscal" name="idFiscal" value="<?= $_SESSION["datos"]["idFiscal"] ?? "" ?>" aria-describedby="idFiscal" placeholder="ID Fiscal">
        <?= isset($errores["idFiscal"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "idFiscal") . '</div>' : ""; ?>
      </div>

      <div class="form-group">
        <label for="contact_name">Cliente </label>
        <input type="text" required class="form-control" id="contact_name" name="contact_name" value="<?= $_SESSION["datos"]["contact_name"] ?? "" ?>" aria-describedby="contact_name" placeholder="Introduce tu nombre">
        <?= isset($errores["contact_name"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "contact_name") . '</div>' : ""; ?>
      </div>


      <div class="form-group">
        <label for="contact_email">Correo electrónico</label>
        <input type="email" required class="form-control" id="contact_email" name="contact_email" value="<?= $_SESSION["datos"]["contact_email"] ?? "" ?>" placeholder="Correo electrónico">
        <?= isset($errores["contact_email"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "contact_email") . '</div>' : ""; ?>
      </div>

      <div class="form-group">
        <label for="contact_phone_number">Teléfono</label>
        <input type="number" class="form-control" id="contact_phone_number" name="contact_phone_number" value="<?= $_SESSION["datos"]["contact_phone_number"] ?? "" ?>" placeholder="Teléfono">
        <?= isset($errores["contact_phone_number"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "contact_phone_number") . '</div>' : ""; ?>
      </div>

      <div class="form-group">
        <label for="company_name">Introduce nombre de Empresa </label>
        <input type="text" required class="form-control" id="company_name" name="company_name" placeholder="Introduce nombre empresa" value="<?= $_SESSION["datos"]["company_name"] ?? "" ?>">
        <?= isset($errores["company_name"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "company_name") . '</div>' : ""; ?>
      </div>
      
      <div class="form-group">
        <label for="company_address">Dirección Empresa</label>
        <input type="text" class="form-control" id="company_address" name="company_address" placeholder="Introduce dirección" value="<?= $_SESSION["datos"]["company_address"] ?? "" ?>">
        <?= isset($errores["company_address"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "company_address") . '</div>' : ""; ?>
      </div>


      <div class="form-group">
        <label for="company_phone_number">Teléfono de la compañia</label>
        <input type="number" class="form-control" id="company_phone_number" name="company_phone_number" value="<?= $_SESSION["datos"]["company_phone_number"] ?? "" ?>" placeholder="Teléfono de la compañia">
        <?= isset($errores["company_phone_number"]) ? '<div class="alert alert-danger" role="alert">' . DibujarErrores($errores, "company_phone_number") . '</div>' : ""; ?>
      </div>


      <button type="submit" class="btn btn-primary">Guardar</button>
      <a class="btn btn-danger" href="index.php">Cancelar</a>
    </form>

    <?php
    //Una vez mostrados los errores, los eliminamos
    unset($_SESSION["datos"]);
    unset($_SESSION["errores"]);
    ?>
  </div>
</main>