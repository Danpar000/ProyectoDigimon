<?php
require_once "controllers/clientsController.php";

$mensaje = "";
$clase = "alert alert-success";
$visibilidad = "hidden";
$mostrarDatos = false;
$controlador = new ClientsController();
$texto = "";
if (!isset($_REQUEST['campo'], $_REQUEST['tipo'])) {
    $campo = 'idFiscal';
    $tipo = 'startswith';
} else {
    $campo = $_REQUEST['campo'];
    $tipo = $_REQUEST['tipo'];
}

if (isset($_REQUEST["evento"])) {
    $mostrarDatos = true;
    switch ($_REQUEST["evento"]) {
        case "todos":
            $clients = $controlador->listar();
            $clients = $controlador->buscar(comprobarSiEsBorrable: true);
            $mostrarDatos = true;
            break;
        case "filtrar":
            $campo=($_REQUEST["campo"])??"idFiscal";
            $metodo=($_REQUEST["tipo"])??"contains";
            $texto=($_REQUEST["busqueda"])??"";
            // $info = ($_REQUEST["busqueda"]) ?? "";
            // // MIRAR
            // $clients = $controlador->buscar($info, $_REQUEST['campo'] ?? "", $_REQUEST['tipo'] ?? "");
            $clients = $controlador->buscar($campo, $metodo, $texto,comprobarSiEsBorrable: true);//solo añadimos esto
            break;
        case "borrar":
            $visibilidad = "visibility";
            $mostrarDatos = true;
            $clase = "alert alert-success";
            //Mejorar y poner el nombre/usuario
            $mensaje = "El cliente con id: {$_REQUEST['id']} fue borrado correctamente";
            if (isset($_REQUEST["error"])) {
                $clase = "alert alert-danger ";
                $mensaje = "ERROR!!! No se ha podido borrar el usuario con id: {$_REQUEST['id']}";
            }
            break;
    }
} ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h3">Buscar cliente</h1>
    </div>
    <div id="contenido">
        <div class="<?= $clase ?>" <?= $visibilidad ?> role="alert">
            <?= $mensaje ?>
        </div>
        <div>
        <form action="index.php?tabla=client&accion=buscar&evento=filtrar" method="POST">
            <div class="form-group">
                <label for="campo">Buscar por</label>
                <select class="form-select" name="campo" id="campo">
                    <option value="idFiscal" <?= $campo == "idFiscal" ? "selected" : ""?>>ID Fiscal</option>
                    <option value="id" <?= $campo == "id" ? "selected" : ""?>>ID</option>
                    <option value="contact_name" <?= $campo == "contact_name" ? "selected" : ""?>>Nombre</option>
                    <option value="contact_email" <?= $campo == "contact_email" ? "selected" : ""?>>Email</option>
                    <option value="contact_phone_number" <?= $campo == "contact_phone_number" ? "selected" : ""?>>Telefono</option>
                    <option value="company_name" <?= $campo == "company_name" ? "selected" : ""?>>Nombre de la compañia</option>
                    <option value="company_address" <?= $campo == "company_address" ? "selected" : ""?>>Direccion de la compañia</option>
                    <option value="company_phone_number" <?= $campo == "company_phone_number" ? "selected" : ""?>>Telefono de la compañia</option>
                </select>
                <label for="campo">Tipo de búsqueda</label>
                <select class="form-select" name="tipo" id="tipo">
                    <option value="startswith" <?= $tipo == "startswith" ? "selected" : ""?> >Empieza por</option>
                    <option value="endswith" <?= $tipo == "endswith" ? "selected" : ""?>>Acaba en</option>
                    <option value="contains" <?= $tipo == "contains" ? "selected" : ""?>>Contiene</option>
                    <option value="equals" <?= $tipo == "equals" ? "selected" : ""?>>Igual a</option>
                </select>

                <label for="busqueda">Buscar</label>
                <input type="text" required class="form-control" id="busqueda" name="busqueda" value="<?= $texto ?>" placeholder="...">
            </div>
            <button type="submit" class="btn btn-success" name="Filtrar"><i class="fas fa-search"></i> Buscar</button>
        </form>
        <!-- Este formulario es para ver todos los datos    -->
        <form action="index.php?tabla=client&accion=buscar&evento=todos" method="POST">
            <button type="submit" class="btn btn-info" name="Todos"><i class="fas fa-list"></i> Listar</button>
        </form>
        </div>
        <?php
        if ($mostrarDatos) {
        ?>
            <table class="table table-light table-hover">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">ID Fiscal</th>
                        <th scope="col">Nombre Contacto</th>
                        <th scope="col">Email</th>
                        <th scope="col">Nº Teléfono Contacto</th>
                        <th scope="col">Nombre Compañía</th>
                        <th scope="col">Dirección Compañía</th>
                        <th scope="col">Nº Teléfono Compañía</th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clients as $client) :
                        $id = $client->id;
                    ?>
                        <tr>
                            <th scope="row"><?= $client->id ?></th>
                            <td><?= $client->idFiscal ?></td>
                            <td><?= $client->contact_name ?></td>
                            <td><?= $client->contact_email ?></td>
                            <td><?= $client->contact_phone_number ?></td>
                            <td><?= $client->company_name ?></td>
                            <td><?= $client->company_address ?></td>
                            <td><?= $client->company_phone_number ?></td>
                            <td>
                                <?php
                                $disable=""; $ruta="index.php?tabla=client&accion=borrar&id={$id}&nombre={$client->contact_name}&idFiscal={$client->idFiscal}";
                                if (isset($client->esBorrable) && $client->esBorrable==false) {
                                    $disable = "disabled"; $ruta="#";
                                }
                                ?>
                                <a class="btn btn-danger <?= $disable?>" href="<?= $ruta?>"><i class="fa fa-trash"></i> Borrar</a></td>
                            <td><a class="btn btn-success" href="index.php?tabla=client&accion=editar&id=<?= $id ?>"><i class="fas fa-pencil-alt"></i> Editar</a></td>
                            </tr>
                    <?php
                    endforeach;

                    ?>
                </tbody>
            </table>
        <?php
        }
        ?>
    </div>
</main>